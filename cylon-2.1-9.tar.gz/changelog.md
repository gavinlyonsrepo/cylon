#version control:
#version 1.0 20-06-16
#verions 1.1 replace echo with printf functions.
#version 1.2 relative paths added 
#version 1.3-1 google drive function added 
#version 1.4-2 090916 extra cower options added
#version 1.5-3 options added for system backup function(dd and gdrive)
#version 1.6-4  120916 Msgfunc added PKGBUILD display added, 
readme install added
#version 1.7-5  140916 Config file added for custom backup paths
#version 1.8-6  180916 added rootkithunter option + update counters
#version 1.9-7  250916 added rmlint option. consolidated menu layout , added more pacman options
#version 2.0-8  011016 added option for lostfiles, system info page,various minor optimisations
#version 2.19-9 051016 added cylon info page with check for optdepends, added error handling for 
missing optdepends in the functions ,changed menus from cat displays to select arrays with prompt. 
Added licence.md and changlog.md, added optdepends array to PKGBUILD. 
